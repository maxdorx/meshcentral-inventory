# MeshCentral Inventory

MeshCentral plugin for workstation lifecycle, user assignment, manual workstation records, and peripheral inventory.

## Requirements

- MeshCentral 1.2.5 or later
- Plugins enabled in `meshcentral-data/config.json`:

```json
"plugins": {
  "enabled": true
}
```

Restart MeshCentral after enabling plugins. Do not add Inventory to `settings.plugins.list`; URL installations are managed by MeshCentral's plugin manager.

## Install

1. Open **My Server â†’ Plugins**.
2. Select **Download Plugin**.
3. Enter:

```text
https://raw.githubusercontent.com/maxdorx/meshcentral-inventory/main/config.json
```

4. Select **OK**.
5. In the Inventory row, select **Install** from **Action**.
6. Refresh MeshCentral and open **Inventory**.
7. Select **Synchronize** for the initial workstation scan.

## Authentication and permissions

Inventory uses the active MeshCentral session. It has no separate login or credentials.

| Permission | Default | Scope |
| --- | --- | --- |
| View inventory | Allowed | View accessible inventory records |
| Manage inventory | Denied | Edit lifecycle, assignments, review decisions, and manual records |
| Synchronize inventory | Denied | Run a full workstation synchronization |

Full administrators can configure plugin permissions from **My Server â†’ Plugins â†’ Inventory â†’ Permissions**.

## Operation

- Agent-backed workstations are created from MeshCentral node and system-information records.
- The first valid signed-in user becomes the assignee. Later users require administrator review.
- Full administrators can add ignored sign-in accounts from **Inventory settings**. Enter one account per line. A plain name such as `adminadmin` matches `adminadmin`, `DAX\adminadmin`, and `adminadmin@dax.local`; a qualified name matches only that exact identity. Matching agent users do not become automatic assignees or signed-in user reviews. Saving a rule clears matching existing pending reviews and agent-derived assignments, but retains manual assignments and audit history.
- Managers can assign a user manually to any workstation. Agent reports with no user keep that assignee; a different reported user appears for review.
- Stale and missing agents raise review without changing the workstation lifecycle. The stale threshold follows MeshCentral's device-group or domain removal setting by default, one day earlier than removal. When removal is disabled, the default is 30 days.
- Full administrators can set a custom stale threshold or disable stale detection from **Inventory settings**. Missing nodes still raise review. Trusted startup, scheduled, and manual synchronization evaluate these conditions; opening the inventory list does not.
- Archived workstations appear under **Archived records** and are excluded from active counts. Returning archived agents require administrator restoration.
- Removed MeshCentral nodes remain as retained inventory records until manually deleted.
- Manual workstations remain separate from agent-backed workstations. Duplicate serial numbers, UUIDs, and asset tags are blocked or flagged for review.
- Unscoped manual workstations and legacy unclassified manual assets are visible only to full administrators.
- An unlinked peripheral has an explicit domain scope and is visible to users who have Inventory view permission in that domain.
- A peripheral linked to an agent-backed workstation inherits that workstation's device-group visibility.
- Manual peripherals and manual workstations keep a separate preservation copy. Trusted startup and synchronization scans restore a missing primary record; confirmed deletion removes both copies.
- Peripheral CSV import validates the complete file before saving any rows.
- Inventory records are stored in MeshCentral's configured database.
- Enabling Inventory uses MeshCentral's Modern UI. Modern themes remain available.

## Updates

MeshCentral checks the installed plugin's `configUrl` for a newer semantic version. When **Latest** shows a newer release, select **Upgrade** from the Inventory row's **Action** menu, then refresh MeshCentral.

MeshCentral retains the `downloadUrl` from the installed plugin record for Upgrade. Version 1.2.1 uses a stable `inventory-current` release tag and a direct ZIP on `raw.githubusercontent.com`. If an older installation has a version-pinned URL, update its files to 1.2.1 once and restart MeshCentral; startup reads the local `config.json` back into the plugin record. The release-channel tag points to the same commit as the latest published version tag.

Updating plugin files does not delete inventory records. Back up `meshcentral-data` before server or plugin upgrades.

## Screenshots

![Workstation inventory dashboard](docs/screenshots/workstations-dashboard.png)

![Workstation inventory details](docs/screenshots/workstation-detail.png)

![Peripheral inventory dashboard](docs/screenshots/peripherals-dashboard.png)

![Peripheral inventory details](docs/screenshots/peripheral-detail.png)

<details>
<summary>Manual entry forms</summary>

![Add a workstation](docs/screenshots/add-workstation.png)

![Add a peripheral](docs/screenshots/add-peripheral.png)

</details>

## Development

```powershell
npm test
npm run package
```

The package command also copies the ZIP to `release-assets/MeshCentral-Inventory.zip`. Commit that exact file with the release code, publish it as both the versioned and fixed-name GitHub release assets, then move `inventory-current` to the tested version-tag commit. Publish the immutable version tag and release before moving the channel tag.

## License

Apache-2.0
